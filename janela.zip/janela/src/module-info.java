/**
 * 
 */
/**
 * 
 */
module janela {
	requires java.desktop;
}